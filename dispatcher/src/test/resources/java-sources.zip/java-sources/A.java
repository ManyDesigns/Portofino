public class A {
    public String string = "class A";
}
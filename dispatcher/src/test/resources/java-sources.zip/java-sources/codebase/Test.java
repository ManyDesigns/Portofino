import com.foo.*;

public class Test {
    public String string = new SomeClass().test();
}
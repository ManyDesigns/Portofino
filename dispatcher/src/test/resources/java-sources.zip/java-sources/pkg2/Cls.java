package some.pkg;

public class Cls {}
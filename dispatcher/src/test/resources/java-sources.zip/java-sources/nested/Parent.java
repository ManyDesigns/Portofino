public class Parent {
    public String string = "class Parent";
}
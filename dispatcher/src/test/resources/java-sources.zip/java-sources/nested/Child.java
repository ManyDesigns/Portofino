public class Child extends Parent {
    public String string = "class Child";
}
package pkg1;

public class Cls {
    public class Inner {}
}